<?php
require_once '../model/Conexion.php';
require_once '../model/Trabajo.php';
class TrabajoController{

    // public static function mostrar(){
    //     try{
    //         $conex=new Conexion();
    //         $result=$conex->query("SELECT * FROM trabajo ORDER BY matricula DESC");
    //         if($result->num_rows){
    //             while($fila=$result->fetch_object()){
    //                 $i=new Trabajo($fila->matricula,
    //                 $fila->cod_mecanico,
    //                 $fila->id_tarea,
    //                 $fila->fecha,
    //                 $fila->estado,
    //                 $fila->horas);
    //                 $trabajos[]=$i;
    //             }
    //         }
    //         else $trabajos=false;
    //         $conex->close();
    //         return $trabajos;            
    //     } catch (Exception $ex) {
    //         die("ERROR CON LA BD: ".$ex->getMessage());
    //     }
    // }

    //mysqli
    // public static function obtenerPorCodMecanico($cod_mecanico){
    //     try{
    //         $conex=new Conexion();
    //         $sql = "SELECT * FROM trabajo WHERE cod_mecanico='$cod_mecanico'";
    //         $result=$conex->execute_query($sql);
    //         $trabajos = [];
    //         if($result->num_rows){
    //             while($reg = $result->fetch_object()){
    //                 $c = new Trabajo(
    //                     $reg->matricula,
    //                     $reg->cod_mecanico,
    //                     $reg->id_tarea,
    //                     $reg->fecha,
    //                     $reg->estado,
    //                     $reg->horas
    //                 );
    //                 $trabajos[] = $c;
    //             }
    //         } else {
    //             $trabajos = false;
    //         }
    //         $conex->close();
    //         return $trabajos;
    //     } catch (Exception $ex) {
    //         die("ERROR CON LA BD: ".$ex->getMessage());
    //     }
    // }

    // public static function obtenerPorCodMecanico($cod_mecanico){
    //     try{
    //         $conex=new Conexion();
    //         $sql = "SELECT * FROM trabajo WHERE cod_mecanico='$cod_mecanico'";
    //         $stmt= $conex->prepare($sql);
    //         $stmt->execute([':cod_mecanico' => $cod_mecanico]);

    //         $trabajos = [];
    //         if($stmt->rowCount()){
    //             while($reg = $stmt->fetch(PDO::FETCH_OBJ)){
    //                 $c = new Trabajo(
    //                     $reg->matricula,
    //                     $reg->cod_mecanico,
    //                     $reg->id_tarea,
    //                     $reg->fecha,
    //                     $reg->estado,
    //                     $reg->horas
    //                 );
    //                 $trabajos[] = $c;
    //             }
    //         } else {
    //             $trabajos = false;
    //         }
    //         $conex->close();
    //         return $trabajos;
    //     } catch (Exception $ex) {
    //         die("ERROR CON LA BD: ".$ex->getMessage());
    //     }
    // }

    public static function mostrar(){
        try{
            $conex = new Conexion();
            $pdo = $conex->getConexion();
            // $sql = "SELECT * FROM trabajo WHERE cod_mecanico='$cod_mecanico' ";

            $sql = "SELECT * FROM trabajo ORDER BY matricula DESC";
            $stmt = $pdo->query($sql);
            
            $trabajos = array();
            if($stmt->rowCount()){
                while($fila = $stmt->fetch(PDO::FETCH_OBJ)){
                    $i = new Trabajo(
                        $fila->matricula,
                        $fila->cod_mecanico,
                        $fila->id_tarea,
                        $fila->fecha,
                        $fila->estado,
                        $fila->horas

                    );
                    $trabajos[] = $i;
                }
            } else {
                $trabajos = false;
            }
            return $trabajos;            
        } catch (PDOException $ex) {
            die("ERROR CON LA BD: " . $ex->getMessage());
        }
    }

    public static function obtenerPorCodMecanico($cod_mecanico){
        try{
            $conex = new Conexion();
            $pdo = $conex->getConexion();
            $sql = "SELECT * FROM trabajo WHERE cod_mecanico='$cod_mecanico' ORDER BY matricula DESC";

            //$sql = "SELECT * FROM trabajo ORDER BY matricula DESC";
            $stmt = $pdo->query($sql);
            
            $trabajos = array();
            if($stmt->rowCount()){
                while($fila = $stmt->fetch(PDO::FETCH_OBJ)){
                    $i = new Trabajo(
                        $fila->matricula,
                        $fila->cod_mecanico,
                        $fila->id_tarea,
                        $fila->fecha,
                        $fila->estado,
                        $fila->horas

                    );
                    $trabajos[] = $i;
                }
            } else {
                $trabajos = false;
            }
            return $trabajos;            
        } catch (PDOException $ex) {
            die("ERROR CON LA BD: " . $ex->getMessage());
        }
    }
}
?>