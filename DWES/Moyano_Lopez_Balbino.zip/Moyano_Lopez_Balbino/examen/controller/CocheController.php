<?php
require_once '../model/Conexion.php';
require_once '../model/Coche.php';
class CocheController{
    public static function buscar($dni_cliente){
        try{
            $conex = new Conexion();
            $pdo = $conex->getConexion();
            
            $sql = "SELECT * FROM coche WHERE dni_cliente = :dni_cliente";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':dni_cliente' => $dni_cliente]);
            
            if($stmt->rowCount()){
                $reg = $stmt->fetch(PDO::FETCH_OBJ);

                $i = new Coche(
                    $reg->matricula,
                    $reg->marca,
                    $reg->modelo,
                    $reg->km,
                    $reg->foto,
                    $reg->dni_cliente
                );
            } else {
                $i = false;
            }
            return $i;
        } catch (PDOException $ex) {
            die("ERROR CON LA BD: " . $ex->getMessage());
        }
    }

    public static function mostrar(){
        try{
            $conex = new Conexion();
            $pdo = $conex->getConexion();
            // $sql = "SELECT * FROM trabajo WHERE cod_mecanico='$cod_mecanico' ";

            $sql = "SELECT * FROM coche ORDER BY matricula DESC";
            $stmt = $pdo->query($sql);
            
            $trabajos = array();
            if($stmt->rowCount()){
                while($fila = $stmt->fetch(PDO::FETCH_OBJ)){
                    $i = new Trabajo(
                        $fila->matricula,
                        $fila->cod_mecanico,
                        $fila->id_tarea,
                        $fila->fecha,
                        $fila->estado,
                        $fila->horas

                    );
                    $trabajos[] = $i;
                }
            } else {
                $trabajos = false;
            }
            return $trabajos;            
        } catch (PDOException $ex) {
            die("ERROR CON LA BD: " . $ex->getMessage());
        }
    }

    public static function mostrarPorDni($dni_cliente){
        try{
            $conex = new Conexion();
            $pdo = $conex->getConexion();

            $sql = "SELECT * FROM coche WHERE dni_cliente = :dni_cliente ORDER BY matricula DESC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':dni_cliente' => $dni_cliente]);
            
            $coches = array();
            if($stmt->rowCount()){
                while($fila = $stmt->fetch(PDO::FETCH_OBJ)){
                    $coche = new Coche(
                        $fila->matricula,
                        $fila->marca,
                        $fila->modelo,
                        $fila->km,
                        $fila->foto,
                        $fila->dni_cliente  
                    );
                    $coches[] = $coche;
                }
            } else {
                $coches = false;
            }
            return $coches;            
        } catch (PDOException $ex) {
            die("ERROR CON LA BD: " . $ex->getMessage());
        }
    }



}
?>