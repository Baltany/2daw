<?php
require_once '../model/Conexion.php';
require_once '../model/Empleado.php';
class EmpleadoController{

    public static function buscarPorCodigo($codigo){
        try{
            $conex = new Conexion();
            $pdo = $conex->getConexion();
            
            $sql = "SELECT * FROM empleado WHERE codigo = :codigo";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':codigo' => $codigo]);
            
            if($stmt->rowCount()){
                $reg = $stmt->fetch(PDO::FETCH_OBJ);
                $u = new Empleado(
                    $reg->codigo,
                    $reg->clave,
                    $reg->nombrecompleto,
                    $reg->telf,
                    $reg->rol
                );
            } else {
                $u = false;
            }
            return $u;
        } catch (PDOException $ex) {
            die("ERROR CON LA BD: " . $ex->getMessage());
        }
    }




}


?>