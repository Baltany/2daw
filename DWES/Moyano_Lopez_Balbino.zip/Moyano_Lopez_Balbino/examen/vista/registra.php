<?php
session_start();
if(!isset($_COOKIE['empleado_codigo'])){
    header("Location:login.php");
    exit;
}
// elseif($_COOKIE['empleado_rol']==="admin"){
//     header("Location:menu.php");
//     exit;


// }

require_once '../controller/EmpleadoController.php';
require_once '../controller/CocheController.php';
require_once '../model/Coche.php';

// $trabajos = TrabajoController::obtenerPorCodMecanico($cod_empleado);
$empleado = EmpleadoController::buscarPorCodigo($_COOKIE['empleado_codigo']);
$regexDni = '/^[0-9]{8}[A-Z]$/';
$regexMatricula = '/^[0-9]{4}[BCDFGHJKLMNPRSTVWXYZ]{3}$/';


function validarExtension($archivo){
$extensionesPermitidas = ['jpg'];
$extension = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));

if (!in_array($extension, $extensionesPermitidas)) {
    return false;
}

$tipos = ['image/jpg'];
if (!in_array($archivo['type'], $tipos)) {
    return false;
}
return true;
}




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registra</title>
</head>
<body>
    <h1>Panel de <?php echo $_COOKIE['empleado_rol'];?></h1>
    
    <p>Bienvenido/a: <?php echo $_COOKIE['empleado_nombrecompleto']; ?> 
    <a href="logout.php">Cerrar Sesión</a>
    <hr>
    <h2>Registrar Trabajo</h2>

    <form method="POST">
        DNI cliente: <input type="text" name="dni" required>
        <input type="submit" name="buscar" value="Buscar">
    </form>
        <br>
    <?php
    if(isset($_POST['buscar'])){
        $dni = $_POST['dni'] ?? '';
        
        if(empty($dni)){
            echo "<p>Por favor ingresa un DNI</p>";
        } else {
            $coches = CocheController::mostrarPorDni($dni);
            
            if($coches && is_array($coches)){
                echo "<br>";
                echo "<b>Coches del cliente '$dni': </b>";
                echo "<table border='1'>";
                echo "<tr><th>Matrícula</th><th>Marca</th><th>Modelo</th><th>Km</th><th>Acciones</th></tr>";
                foreach($coches as $coche){
                    echo "<tr>";
                    echo "<td>".$coche->getMatricula()."</td>";
                    echo "<td>".$coche->getMarca()."</td>";
                    echo "<td>".$coche->getModelo()."</td>";
                    echo "<td>".$coche->getKm()."</td>";
                    echo "<td>";
                    echo "<a href='editar_item.php?id=".$coche->getMatricula() ."'>Seleccionar</a>";
                    echo "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No hay coches registrados para este DNI</p>";
            }
            echo "<br>";
        }
    }
    ?>



    <form action="" method="POST" enctype="multipart/form-data">
        <b>Matricula:</b> <input type="text" name="matricula" required><br><br>
        
        <b>Marca:</b> <input type="text" name="marca" required><br><br>
        
        <b>Modelo:</b> <input type="text" name="modelo" required><br><br>
        
        <b>Km:</b> <input type="text" name="km" required><br><br>
                
        <b>Foto:</b> <input type="file" name="imagen" accept="imagenes/*"><br><br>
        
        <input type="submit" name="crear" value="Nuevo">
    </form>
    
        <a href="menu.php">Volver</a>
</body>
</html>