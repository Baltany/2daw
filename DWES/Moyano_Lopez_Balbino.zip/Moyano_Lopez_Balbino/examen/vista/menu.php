<?php
session_start();

if(!isset($_COOKIE['empleado_codigo']) || empty($_COOKIE['empleado_codigo'])){
    header("Location: login.php");
    exit();
}

require_once  '../model/Empleado.php';
require_once  '../controller/EmpleadoController.php';

$empleado = EmpleadoController::buscarPorCodigo($_COOKIE['empleado_codigo']);

if(!$empleado){
    setcookie("empleado_codigo", "", time()-3600, "/");
    setcookie("empleado_nombrecompleto", "", time()-3600, "/");
    setcookie("empleado_telf", "", time()-3600, "/");
    setcookie("empleado_rol", "", time()-3600, "/");
    header("Location: login.php");
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
</head>
<body>
    <h1>Panel de <?php echo $empleado->rol;?></h1>
    
    <p>Bienvenido/a: <?php echo $empleado->nombrecompleto; ?> 
    <a href="logout.php">Cerrar Sesión</a>
    <?php if($empleado->esAdmin()): ?>
        <strong>(Administrador)</strong>
    <?php endif; ?>
    <br>
    <a href="trabajo.php">Ver Trabajo</a> 
    <?php if($empleado->esAdmin()): ?>
        | <a href="registra.php"> | Registrar Trabajo</a>
    <?php endif; ?>

    </p>
</body>
</html>