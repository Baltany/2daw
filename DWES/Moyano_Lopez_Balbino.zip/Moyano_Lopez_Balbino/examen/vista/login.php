<?php
session_start();
if(isset($_COOKIE['empleado_id'])){
    header("Location:index.php");
}
require_once '../model/Empleado.php';
require_once '../controller/EmpleadoController.php';

// 88888	$2y$10$TdEjaVZZdiSFNxupl1PD.e02A.FFJB1a6l1rljTXENnq2hOyLyEiy
// 99999	$2y$10$eiXN0MERY5NZcL3nP/cbieZbSBbxtME7LTH.I1TKCZrCEpk0xhzgK

if(isset($_POST['entrar'])){
    $codigo=$_POST['codigo'];
    $pass=$_POST['clave'];
    
    if(empty($codigo)){
        $error_codigo="El codigo es obligatorio";
    }else{
        $u=EmpleadoController::buscarPorCodigo($codigo);
        if(!$u){
            $error_codigo="El empleado no existe";
        }else{
            if(password_hash($pass,$u->password)){
                setcookie("empleado_codigo",$u->codigo,time()+3600,"/");
                setcookie("empleado_nombrecompleto",$u->nombrecompleto,time()+3600,"/");
                setcookie("empleado_telf",$u->telf,time()+3600,"/");
                setcookie("empleado_rol",$u->rol,time()+3600,"/");
                header("Location:menu.php");
            }else{
                $error_pass="La contraseña es incorrecta";
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Iniciar Sesión</h1>

    <form action="" method="POST">
        Codigo: <input type="text" name="codigo" required><br>
        <?php if(isset($error_codigo)) echo "<span style='color:red;'>$error_codigo</span><br>"; ?>
        Contraseña: <input type="password" name="clave" required><br>
        <?php if(isset($error_pass)) echo "<span style='color:red;'>$error_pass</span><br>"; ?>
        <input type="submit" name="entrar" value="Entrar"><br>
    </form>
    
</body>
</html>