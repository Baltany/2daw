<?php
session_start();
if(!isset($_COOKIE['empleado_codigo'])){
    header("Location:login.php");
    exit;
}

$cod_empleado = $_COOKIE['empleado_codigo'];

require_once '../controller/TrabajoController.php';
require_once '../controller/EmpleadoController.php';
require_once '../model/Trabajo.php';

$trabajos = TrabajoController::obtenerPorCodMecanico($cod_empleado);
//$trabajo = TrabajoController::mostrar();
$empleado = EmpleadoController::buscarPorCodigo($_COOKIE['empleado_codigo']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabajo</title>
</head>
<body>
    <h1>Panel de <?php echo $_COOKIE['empleado_rol'];?></h1>
    
    <p>Bienvenido/a: <?php echo $_COOKIE['empleado_nombrecompleto']; ?> 
    <a href="logout.php">Cerrar Sesión</a>
    
    <!-- Separador -->
    <hr>
    <?php if($empleado->esMecanico()): ?>
    <h2>Mis Trabajos</h2>

    <?php
    // var_dump($trabajos);
    if($trabajos){
        echo "<table border='1'>";
        echo "<tr><th>Matricula</th><th>Tarea</th><th>Estado</th><th>Horas</th><th>Acciones</th></tr>";

        foreach($trabajos as $c){
            echo "<tr>";
            echo "<td>" . $c->matricula . "</td>";
            echo "<td>" . $c->id_tarea . " </td>";
            echo "<td>" . $c->estado . " </td>";
            echo "<td>" . $c->horas . " </td>";
            // echo "<td> <a href=''>Actualizar</a> </td>";
            echo "<td> <a href='transferencias.php?=" . $c-> matricula. "'>Actualizar</a> </td>";        echo "</tr>";
        }

        echo "</table><br>";
    }else{
        echo "<p>No tienes trabajos registradas.</p>";
    }
    ?>
    <?php endif; ?>
    <?php if($empleado->esAdmin()): ?>
    <h2>Trabajos</h2>
        <form action="" method="post">
            Matricula : <input type="text" name="matricula">
            Dia: <input type="date" name="fecha">
            <input type="submit" name="enviar" value="Buscar">
        </form>
    <?php endif; ?>


        <a href="menu.php">Volver</a>


</body>
</html>