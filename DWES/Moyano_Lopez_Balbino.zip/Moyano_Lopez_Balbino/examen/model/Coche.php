<?php
require_once 'Conexion.php';

class Coche{
    private $matricula;
    private $marca;
    private $modelo;
    private $km;
    private $foto;
    private $dni_cliente;

    public function __construct($matricula="",$marca="",$modelo="",$km="",$foto="",$dni_cliente="") {
        $this->matricula=$matricula;
        $this->marca=$marca;
        $this->modelo=$modelo;
        $this->km=$km;
        $this->foto=$foto;
        $this->dni_cliente = $dni_cliente;

    }
    public function insertar($coche){
        try{
            $conex = new Conexion();
            $pdo = $conex->getConexion();
            $sql="INSERT INTO coche VALUES ('$this->matricula', '$this->marca', '$this->modelo', $this->km, $this->foto')";

            $stmt=$pdo -> prepare($sql);
            $resultado = $stmt->execute([
                ':matricula' => $coche->nombre,
                ':marca' => $coche->apellidos,
                ':modelo' => $coche->provincia,
                ':km' => $coche->sexo,
                ':foto' => $coche->edad
            ]);

            $conex->close();
            return $resultado ? $stmt->rowCount() : 0;
        }catch(Exception $ex){
            die("ERROR CON LA BD: " . $ex->getMessage());
        }
    }

        public function getMatricula() {
        return $this->matricula;
    }

    public function getMarca() {
        return $this->marca;
    }

    public function getModelo() {
        return $this->modelo;
    }

    public function getKm() {
        return $this->km;
    }

    public function getFoto() {
        return $this->foto;
    }

    public function getDniCliente() {
        return $this->dni_cliente;
    }

    public function setMatricula($matricula) {
        $this->matricula = $matricula;
    }

    public function setMarca($marca) {
        $this->marca = $marca;
    }

    public function setModelo($modelo) {
        $this->modelo = $modelo;
    }

    public function setKm($km) {
        $this->km = $km;
    }

    public function setFoto($foto) {
        $this->foto = $foto;
    }

    public function setDniCliente($dni_cliente) {
        $this->dni_cliente = $dni_cliente;
    }

}

?>