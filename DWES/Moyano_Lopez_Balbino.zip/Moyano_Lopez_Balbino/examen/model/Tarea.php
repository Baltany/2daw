<?php
class Tarea{
    private $id;
    private $descripcion;
    private $precio;
    private $tipo;



}

?>